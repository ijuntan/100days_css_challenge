# #1 Gradient Background with Custom Number

A Pen created on CodePen.io. Original URL: [https://codepen.io/Junior-Tanaya/pen/qBvPoqo](https://codepen.io/Junior-Tanaya/pen/qBvPoqo).

