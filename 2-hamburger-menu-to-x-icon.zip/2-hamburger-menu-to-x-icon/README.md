# #2 Hamburger Menu to X icon

A Pen created on CodePen.io. Original URL: [https://codepen.io/Junior-Tanaya/pen/gOEGqqd](https://codepen.io/Junior-Tanaya/pen/gOEGqqd).

