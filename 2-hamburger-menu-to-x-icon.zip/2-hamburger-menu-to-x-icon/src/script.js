function click_menu() {
	var element = document.getElementById("one")
	if(!element.classList.contains("bar-one")){
		element.classList.add("bar-one")
		element.classList.remove("bar-one-back")
	}
	else {
		element.classList.add("bar-one-back")
		element.classList.remove("bar-one")
	}
	
	var element = document.getElementById("two")
	if(!element.classList.contains("bar-two")){
		element.classList.add("bar-two")
		element.classList.remove("bar-two-back")
	}
	else {
		element.classList.add("bar-two-back")
		element.classList.remove("bar-two")
	}
	
	var element = document.getElementById("three")
	if(!element.classList.contains("bar-three")){
		element.classList.add("bar-three")
		element.classList.remove("bar-three-back")
	}
	else {
		element.classList.add("bar-three-back")
		element.classList.remove("bar-three")
	}
}